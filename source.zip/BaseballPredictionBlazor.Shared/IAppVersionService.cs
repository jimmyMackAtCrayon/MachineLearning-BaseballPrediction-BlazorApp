﻿using System;
using System.Collections.Generic;
using System.Text;

namespace BaseballPredictionBlazor.Shared
{
    public interface IAppVersionService
    {
        string Version { get; }
    }
}
